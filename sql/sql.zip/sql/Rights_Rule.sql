INSERT INTO Rights_Rule (Rule_Id, Rule_Description, Rule_RightType, Rule_AirsPerRelease) VALUES (150, 'Release', 'R', 99);
INSERT INTO Rights_Rule (Rule_Id, Rule_Description, Rule_RightType, Rule_AirsPerRelease) VALUES (151, 'Unlimited', 'U', 1);
INSERT INTO Rights_Rule (Rule_Id, Rule_Description, Rule_RightType, Rule_AirsPerRelease) VALUES (152, 'Perpetual', 'P', 1);
INSERT INTO Rights_Rule (Rule_Id, Rule_Description, Rule_RightType, Rule_AirsPerRelease) VALUES (156, 'Telecast', 'T', 1);
INSERT INTO Rights_Rule (Rule_Id, Rule_Description, Rule_RightType, Rule_AirsPerRelease) VALUES (157, 'Unknown', 'Unknown', -1);
