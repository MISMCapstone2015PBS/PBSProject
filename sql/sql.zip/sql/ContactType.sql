INSERT INTO ContactType (ContactType_Id, ContactType_Code) VALUES (44001, 'Primary Producer');
INSERT INTO ContactType (ContactType_Id, ContactType_Code) VALUES (44002, 'Additional Producer');
INSERT INTO ContactType (ContactType_Id, ContactType_Code) VALUES (44003, 'Primary Presenter');
INSERT INTO ContactType (ContactType_Id, ContactType_Code) VALUES (44004, 'Additional Presenter');
INSERT INTO ContactType (ContactType_Id, ContactType_Code) VALUES (44005, 'Copyright Holder');
INSERT INTO ContactType (ContactType_Id, ContactType_Code) VALUES (44006, 'Public Relations');
