INSERT INTO Rights_Group (Group_Id, Group_Description) VALUES (5000, 'TV - Primary Channel');
INSERT INTO Rights_Group (Group_Id, Group_Description) VALUES (6000, 'TV - Secondary (Multicast) Channel');
