INSERT INTO Rating (Rating_Id, Rating_Code, Rating_Description, Rating_IsArchived) VALUES (3124912, '14    ', 'Parents Strongly Cautioned', 0);
INSERT INTO Rating (Rating_Id, Rating_Code, Rating_Description, Rating_IsArchived) VALUES (3124913, 'RE    ', 'Exempt', 0);
INSERT INTO Rating (Rating_Id, Rating_Code, Rating_Description, Rating_IsArchived) VALUES (3124914, 'G     ', 'General Audience', 0);
INSERT INTO Rating (Rating_Id, Rating_Code, Rating_Description, Rating_IsArchived) VALUES (3124915, 'MA    ', 'Mature Audience Only', 0);
INSERT INTO Rating (Rating_Id, Rating_Code, Rating_Description, Rating_IsArchived) VALUES (3124916, 'PG    ', 'Parental Guidance Suggested', 0);
INSERT INTO Rating (Rating_Id, Rating_Code, Rating_Description, Rating_IsArchived) VALUES (3124917, 'Y     ', 'All Children', 0);
INSERT INTO Rating (Rating_Id, Rating_Code, Rating_Description, Rating_IsArchived) VALUES (3124918, 'Y7    ', 'Children 7 and Older', 0);
