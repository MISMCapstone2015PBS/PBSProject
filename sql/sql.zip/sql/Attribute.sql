INSERT INTO Attribute (Attribute_Id, Attribute_Code, Attribute_Description, Attribute_IsArchived) VALUES (3139090, 'COM   ', 'Common Carry', 0);
INSERT INTO Attribute (Attribute_Id, Attribute_Code, Attribute_Description, Attribute_IsArchived) VALUES (3146239, 'BW    ', 'BLACK AND WHITE', 0);
INSERT INTO Attribute (Attribute_Id, Attribute_Code, Attribute_Description, Attribute_IsArchived) VALUES (3146240, 'CBW   ', 'COLOR W/ BLACK AND WHITE', 0);
INSERT INTO Attribute (Attribute_Id, Attribute_Code, Attribute_Description, Attribute_IsArchived) VALUES (9290858, 'PRIMET', 'Primetime', 0);
INSERT INTO Attribute (Attribute_Id, Attribute_Code, Attribute_Description, Attribute_IsArchived) VALUES (9290866, 'CHILD ', 'Children\'s', 0);
INSERT INTO Attribute (Attribute_Id, Attribute_Code, Attribute_Description, Attribute_IsArchived) VALUES (134518070, NULL, 'Purged', 0);
INSERT INTO Attribute (Attribute_Id, Attribute_Code, Attribute_Description, Attribute_IsArchived) VALUES (139519624, 'IMG   ', 'Image', 0);
